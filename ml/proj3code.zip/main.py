import numpy as np
import cPickle
import gzip
import math
filename = 'mnist.pkl.gz'
f = gzip.open(filename, 'rb')
training_data, validation_data, test_data = cPickle.load(f)
f.close()
labeltrain=training_data[1]
labelval=validation_data[1]
labeltest=test_data[1]
valimage=validation_data[0]
testimage=test_data[0]
trainimage=np.insert(training_data[0],0,1,axis=1)
trainimg=training_data[0]
# # print train
# # print train.shape
binarylabel=np.zeros((50000,10))
for i in range(50000):
	 binarylabel[i][labeltrain[i]]=1
# print binarylabel
weights=np.random.rand(785,10)
for i in range(100):
	print "Executing iteration",i
	y=np.dot(trainimage,weights)
	numerator=np.exp(y)
	# print numerator
	# print numerator.shape
	denominator=np.sum(numerator,axis=1)
	# print denominator.shape
	# numerator2=numerator
	for i in range(0,50000):
		numerator[i]=numerator[i]/denominator[i]
	# for i in range(0,50000):
		# for j in range(0,10):
			# numerator[i][j]=numerator2[i][j]/denominator[i]
	# print numerator
	# print numerator2
	
	# print binarylabel
	derivative=np.dot(np.transpose(trainimage),(numerator-binarylabel))
	# print derivative
	# print derivative.shape
	lr=0.5
	weights=weights-lr*derivative/50000
# print weights
# print numerator
Y_class = np.zeros(50000)
# print numerator
# print labeltrain
for i in range(50000):
	max=0
	for j in range(10):
		if numerator[i][j]>max:
			max=numerator[i][j]
			position=j
	Y_class[i] = position
# f=open("demo.txt",'w')
# f.write(str(numerator[0]))
# f.close()
# print Y_class
count=0
for i in range(50000):
	if(Y_class[i]==labeltrain[i]):
		count=count+1
print count
efficiency=(count*100)/50000
print "Effiency of the training dataset by using Logistic Regression"
print efficiency 
#-------Neural Networks------#
def softmax(mat):
	top=np.exp(mat)
	bot=np.sum((top),axis=0)
	#for i in range(10):
	top=top/bot
	return top
weight1=np.random.rand(784,1000)*0.1
weight2=np.random.rand(1000,10)*0.1
b1 = np.ones((1,1000),dtype='float')
b2 = np.ones((1,10),dtype='float')
Yclass=np.zeros((50000,1))
for i in range(50000):
	print "Executing iteration",i
	zj=np.dot(trainimg[i],weight1)+ b1
	#print zj.shape
	#print np.transpose(zj).shape
	hzj=1 / (1 + (np.exp(-zj)))
	#print hzj
	#print hzj.shape
	ak=np.dot(hzj,weight2)+ b2
	yk=softmax(ak)
	binlab=np.array([binarylabel[i]])
	#print yk.shape
	#print binlab.shape
	etak=yk-binlab
	#print etak.shape
	hdashj=np.dot(hzj,np.transpose(1-hzj))
	#print hdashj.shape
	mul=np.dot(weight2,np.transpose(etak))
	etaj=hdashj*mul
	# #etaj=np.dot(etak,weight2)#*derivative of sigmoid function
	# #print etaj.shape
	# #etajt=np.transpose(etaj)
	# #print etajt.shape
	
	trnimg=np.array([trainimg[i]])
	derivative1=np.dot(np.transpose(trnimg),np.transpose(etaj))
	derivative2=np.dot(np.transpose(zj),etak)
	
	print derivative1.shape
	# #print derivative1.shape
	# #print derivative2.shape
	lr=0.01
	weight1=weight1-lr*derivative1 #/20000 #/50000
	weight2=weight2-lr*derivative2 #/20000 #/50000
zj=np.dot(trainimg,weight1)
# #print zj.shape
# #print np.transpose(zj).shape
# #top1=np.exp(zj)
# #bot1=np.sum(zj,axis=0)
# #for i in range(0,50000):
# #	top1=top1/bot1
# #hzj=top1
hzj=1 / (1 + (np.exp(-zj)))
# #print hzj
# #print hzj.shape
ak=np.dot(hzj,weight2)
yk=softmax(ak)
for i in range(50000):
    max=np.argmax(yk[i])
    Yclass[i] = max
count=0
for i in range(50000):
  if(Yclass[i]==labeltrain[i]):
		  count=count+1
print count
efficiency=(count*100)/50000
print "Efficiency of the training dataset by using Single Neural Networks"
print efficiency

	
# # ak=np.dot(zj,weight2)
# # print ak.shape
# # print softmax(ak)

# #---------------------------------------Tuning-------------------------
# #derivativenn=np.dot(np.transpose(trainimage),(numerator-binarylabel))
# # nume=np.exp(ak)
# # deno=np.sum(nume,axis=1)
# # for i in range(0,50000):
		# # nume[i]=nume[i]/deno[i]
# # print nume

# #import math
# #print 1/(1+(np.exp(-ak)))
# def sigmoid(x):
   # return 1 / (1 + np.exp(-x))
# # sigmoid(ak)
# # print ak
# # print denominator
# # print denominator.shape
# # print denominator.shape
# # div=np.divide(numerator,denominator)
# # print div.shape
# # print div
# # print labeltrain
# # err=np.dot(y,np.subtract(div,labeltrain))
# # print err
# # print validation_data.shape